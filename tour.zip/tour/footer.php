<section class="footer" >
   <div class=" container-fluid">
      <div class="col-xs-12 text-center footer-content">
         <ul class="social-icons" data-aos="fade-up">
            <li> <a href="javaScript:void(0);" alt="Facebook" title="Facebook"> <i class="fab fa-facebook-f"></i></a> </li>
            <li> <a href="javaScript:void(0);" alt="Twitter" title="Twitter"> <i class="fab fa-twitter"></i></a> </li>
            <li> <a href="javaScript:void(0);" alt="Linkedin" title="Linkedin"> <i class="fab fa-linkedin-in"></i></a> </li>
            <li><a href="javaScript:void(0);" alt="Instagram" title="Instagram"><i class="fab fa-instagram"></i></a> </li>
         </ul>
         <h4 class="footer-title">Tour Travel Private Limited</h4>
         <p>123, Dummy Apt,<br/>
            Anand Nagar, S.V.Road,<br/>
            Bandra (w), Mumbai<br/>
            <i class="fas fa-phone-alt"></i> : <a href="tel:+1234567890" alt="1234567890" title="1234567890" class="tel-icon">1234567890</a>
         </p>
      </div>
      <div class="col-xs-12  text-center copyright container">
         <hr>
         <p>&copy; copyright 2019. All rights reserved.</p>
      </div>
	  <a class="scroll-top" href="#"><i class="fas fa-chevron-circle-up"></i></a>
   </div>
</section>
<script src="js/custom-js.js"></script>
  <script>
    $("a.scroll-top").click(function() {
      $("html, body").animate({ scrollTop: 0 }, "slow");
      return false;
  });
  </script>
</body>
</html>