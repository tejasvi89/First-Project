<?php 
$activePage = basename($_SERVER['PHP_SELF'], ".html"); ?>

<!DOCTYPE html>

<html lang="en">
   <head>
      <title>Tour Travel</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/custom-style.css">
	  <link rel="stylesheet" href="css/responsive.css">
      <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:300,400,700&display=swap" rel="stylesheet">
      <link href="css/all.css" rel="stylesheet">
      <link rel="stylesheet" href="css/aos.css">
      <script src="js/3.4.1.jquery.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
     <script src="js/aos.js"></script>
      <script defer src="js/all.js"></script> 
   </head>
   <body >

      <nav class="navbar">
         <div class="container-fluid">
            <div class="navbar-header">
               <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>                        
               </button>
               <a class="navbar-brand" href="/"><img src="images/logo-white.png" class="img-responsive" alt="tour" title="tour"></a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
               <ul class="nav navbar-nav navbar-right">
 <li class="<?= ($activePage == 'index') ? 'active':''; ?>"><a href="index.html" class="hover-animation" alt="Home" title="Home">Home</a></li> 			   			         
    <li class="<?= ($activePage == 'blog') ? 'active':''; ?>"><a href="blog.html" class="hover-animation" alt="Blog" title="Blog">Blog</a></li>  
	<li class="<?= ($activePage == 'contact-us') ? 'active':''; ?>"><a href="contact-us.html" class="hover-animation" alt="Contact Us" title="Contact Us">Contact Us</a></li>    
                
               </ul>
            </div>
         </div>
      </nav>